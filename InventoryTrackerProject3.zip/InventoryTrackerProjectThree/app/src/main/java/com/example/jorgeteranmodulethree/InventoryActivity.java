package com.example.jorgeteranmodulethree;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private DatabaseHelper databaseHelper;
    private SmsAlertManager smsAlerts;

    private LinearLayout inventoryContainer;
    private EditText itemNameEditText;
    private EditText quantityEditText;
    private TextView emptyInventoryText;
    private Button addItemButton;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    // Represents one inventory record stored in SQLite.
    private static class InventoryItem {
        final long id;
        final String name;
        final int quantity;

        InventoryItem(long id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }
    }

    private interface DatabaseChange {
        boolean execute();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        inventoryContainer = findViewById(R.id.inventoryContainer);
        itemNameEditText = findViewById(R.id.itemNameEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        emptyInventoryText = findViewById(R.id.emptyInventoryText);
        addItemButton = findViewById(R.id.addItemButton);

        Button smsButton = findViewById(R.id.smsNotificationButton);

        smsAlerts = new SmsAlertManager(this);

        addItemButton.setOnClickListener(view -> addItem());
        smsButton.setOnClickListener(view -> smsAlerts.enableAlerts());

        loadInventory();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh permission status after returning from device settings.
        if (smsAlerts != null) {
            smsAlerts.refreshStatus();
        }
    }

    private void addItem() {
        String name = itemNameEditText.getText().toString().trim();

        if (name.isEmpty()) {
            itemNameEditText.setError("Enter an item name.");
            itemNameEditText.requestFocus();
            return;
        }

        Integer quantity = validateQuantity(quantityEditText);

        if (quantity == null) {
            return;
        }

        saveChange(
                () -> databaseHelper.addItem(name, quantity),
                "Item added.",
                true,
                quantity == 0 ? name : null
        );
    }

    // Accept only whole numbers that fit in the database quantity field.
    private Integer validateQuantity(EditText field) {
        String value = field.getText().toString().trim();

        try {
            int quantity = Integer.parseInt(value);

            if (quantity < 0) {
                throw new NumberFormatException();
            }

            return quantity;
        } catch (NumberFormatException exception) {
            field.setError("Enter a whole number from 0 to 2147483647.");
            field.requestFocus();
            return null;
        }
    }

    private List<InventoryItem> readItems() {
        List<InventoryItem> items = new ArrayList<>();

        // Closing the cursor releases its database resources.
        try (Cursor cursor = databaseHelper.getAllItems()) {
            int idColumn = cursor.getColumnIndexOrThrow("id");
            int nameColumn = cursor.getColumnIndexOrThrow("name");
            int quantityColumn = cursor.getColumnIndexOrThrow("quantity");

            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(idColumn),
                        cursor.getString(nameColumn),
                        cursor.getInt(quantityColumn)
                ));
            }
        }

        return items;
    }

    private void loadInventory() {
        setBusy(true);

        databaseExecutor.execute(() -> {
            try {
                List<InventoryItem> items = readItems();

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    displayItems(items);
                    setBusy(false);
                });
            } catch (RuntimeException exception) {
                showDatabaseError();
            }
        });
    }

    // Use this version for changes that do not trigger an SMS.
    private void saveChange(
            DatabaseChange change,
            String successMessage,
            boolean clearInputs
    ) {
        saveChange(change, successMessage, clearInputs, null);
    }

    // Save first, refresh the inventory, then request any zero-stock alert.
    private void saveChange(
            DatabaseChange change,
            String successMessage,
            boolean clearInputs,
            String zeroStockItem
    ) {
        setBusy(true);

        databaseExecutor.execute(() -> {
            try {
                boolean saved = change.execute();
                List<InventoryItem> items = readItems();

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    displayItems(items);
                    setBusy(false);

                    if (saved && clearInputs) {
                        itemNameEditText.setText("");
                        quantityEditText.setText("");
                    }

                    Toast.makeText(
                            this,
                            saved
                                    ? successMessage
                                    : "Change could not be saved.",
                            Toast.LENGTH_SHORT
                    ).show();

                    if (saved && zeroStockItem != null) {
                        smsAlerts.sendZeroStockAlert(zeroStockItem);
                    }
                });
            } catch (RuntimeException exception) {
                showDatabaseError();
            }
        });
    }

    private void displayItems(List<InventoryItem> items) {
        inventoryContainer.removeAllViews();

        emptyInventoryText.setVisibility(
                items.isEmpty() ? View.VISIBLE : View.GONE
        );

        for (InventoryItem item : items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(8), dp(8), dp(8));

            TextView name = new TextView(this);
            name.setText(item.name);
            name.setTextSize(16);
            name.setTextColor(Color.parseColor("#222222"));

            row.addView(
                    name,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            2
                    )
            );

            TextView quantity = new TextView(this);
            quantity.setText(String.valueOf(item.quantity));
            quantity.setTextSize(16);
            quantity.setGravity(Gravity.CENTER);
            quantity.setTextColor(Color.parseColor("#222222"));

            row.addView(
                    quantity,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1
                    )
            );

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.VERTICAL);

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setContentDescription("Edit " + item.name);
            editButton.setOnClickListener(view -> editItem(item));
            actions.addView(editButton);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setContentDescription("Delete " + item.name);
            deleteButton.setOnClickListener(view -> confirmDelete(item));
            actions.addView(deleteButton);

            row.addView(
                    actions,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            2
                    )
            );

            inventoryContainer.addView(row);

            View divider = new View(this);
            divider.setBackgroundColor(Color.parseColor("#D6DCE4"));

            inventoryContainer.addView(
                    divider,
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(1)
                    )
            );
        }
    }

    private void editItem(InventoryItem item) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText nameField = new EditText(this);
        nameField.setHint("Item name");
        nameField.setContentDescription("Item name");
        nameField.setInputType(
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_CAP_WORDS
        );
        nameField.setSingleLine(true);
        nameField.setText(item.name);
        form.addView(nameField);

        EditText quantityField = new EditText(this);
        quantityField.setHint("Quantity");
        quantityField.setContentDescription("Quantity");
        quantityField.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantityField.setText(String.valueOf(item.quantity));
        form.addView(quantityField);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Item")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        // Invalid entries leave the dialog open for correction.
        dialog.setOnShowListener(unused ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(view -> {
                            String newName =
                                    nameField.getText().toString().trim();

                            if (newName.isEmpty()) {
                                nameField.setError("Enter an item name.");
                                nameField.requestFocus();
                                return;
                            }

                            Integer newQuantity =
                                    validateQuantity(quantityField);

                            if (newQuantity == null) {
                                return;
                            }

                            dialog.dismiss();

                            // Alert only when a positive quantity reaches zero.
                            String zeroStockItem =
                                    item.quantity > 0 && newQuantity == 0
                                            ? newName
                                            : null;

                            saveChange(
                                    () -> databaseHelper.updateItem(
                                            item.id,
                                            newName,
                                            newQuantity
                                    ),
                                    "Item updated.",
                                    false,
                                    zeroStockItem
                            );
                        })
        );

        dialog.show();
    }

    private void confirmDelete(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Remove " + item.name + " from inventory?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) ->
                        saveChange(
                                () -> databaseHelper.deleteItem(item.id),
                                "Item deleted.",
                                false
                        )
                )
                .show();
    }

    private void setBusy(boolean busy) {
        addItemButton.setEnabled(!busy);
        itemNameEditText.setEnabled(!busy);
        quantityEditText.setEnabled(!busy);
        setChildrenEnabled(inventoryContainer, !busy);
    }

    private void setChildrenEnabled(
            LinearLayout layout,
            boolean enabled
    ) {
        for (int index = 0; index < layout.getChildCount(); index++) {
            View child = layout.getChildAt(index);
            child.setEnabled(enabled);

            if (child instanceof LinearLayout) {
                setChildrenEnabled((LinearLayout) child, enabled);
            }
        }
    }

    private void showDatabaseError() {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }

            setBusy(false);

            Toast.makeText(
                    this,
                    "Unable to access inventory. Please try again.",
                    Toast.LENGTH_LONG
            ).show();
        });
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE && smsAlerts != null) {
            smsAlerts.permissionResult();
        }
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }

    @Override
    protected void onDestroy() {
        // Close the database after previously queued work finishes.
        databaseExecutor.execute(() -> {
            if (databaseHelper != null) {
                databaseHelper.close();
            }
        });

        databaseExecutor.shutdown();

        if (smsAlerts != null) {
            smsAlerts.close();
        }

        super.onDestroy();
    }
}