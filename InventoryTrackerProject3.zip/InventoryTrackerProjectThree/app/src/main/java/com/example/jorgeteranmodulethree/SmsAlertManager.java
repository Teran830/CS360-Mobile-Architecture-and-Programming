package com.example.jorgeteranmodulethree;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsAlertManager {

    private static final int SMS_PERMISSION_CODE = 100;

    private final AppCompatActivity activity;
    private final EditText phoneField;
    private final TextView statusText;
    private final SharedPreferences preferences;
    private final String sentAction;

    private boolean waitingForPermission = false;
    private int requestNumber = 0;

    // Android reports whether the outgoing SMS succeeded or failed.
    private final BroadcastReceiver sentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (getResultCode() == Activity.RESULT_OK) {
                statusText.setText(
                        "SMS sent. Recipient delivery is not confirmed."
                );
            } else {
                statusText.setText(
                        "Inventory saved, but SMS failed. Result code: "
                                + getResultCode()
                                + ". Check cellular service and the SMS SIM."
                );
            }
        }
    };

    public SmsAlertManager(AppCompatActivity activity) {
        this.activity = activity;

        phoneField = activity.findViewById(R.id.phoneNumberEditText);
        statusText = activity.findViewById(R.id.smsStatusText);

        preferences = activity.getSharedPreferences(
                "stock_alert_settings",
                Context.MODE_PRIVATE
        );

        phoneField.setText(preferences.getString("phone", ""));

        sentAction = activity.getPackageName() + ".STOCK_SMS_SENT";

        ContextCompat.registerReceiver(
                activity,
                sentReceiver,
                new IntentFilter(sentAction),
                ContextCompat.RECEIVER_NOT_EXPORTED
        );

        refreshStatus();
    }

    private boolean hasPermission() {
        return ContextCompat.checkSelfPermission(
                activity,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public void enableAlerts() {
        String phone = phoneField.getText().toString()
                .replaceAll("[\\s()\\-]", "");

        // Allow normal phone numbers and emulator test destinations.
        boolean emulatorNumber = phone.matches("555[468]");
        boolean normalNumber = phone.matches("\\+?[0-9]{7,15}");

        if (!normalNumber && !emulatorNumber) {
            phoneField.setError("Enter a phone number with area code.");
            phoneField.requestFocus();
            return;
        }

        preferences.edit()
                .putString("phone", phone)
                .apply();

        if (hasPermission()) {
            preferences.edit().putBoolean("enabled", true).apply();
            refreshStatus();
        } else {
            waitingForPermission = true;

            ActivityCompat.requestPermissions(
                    activity,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    public void permissionResult() {
        if (waitingForPermission) {
            preferences.edit()
                    .putBoolean("enabled", hasPermission())
                    .apply();

            waitingForPermission = false;
        }

        refreshStatus();
    }

    public void refreshStatus() {
        boolean enabled = preferences.getBoolean("enabled", false);

        if (enabled && hasPermission()) {
            statusText.setText(
                    "SMS alerts enabled for "
                            + preferences.getString("phone", "")
                            + ". Change the number and tap Enable to update it."
            );
        } else {
            statusText.setText(
                    "SMS alerts are off. You can still manage inventory."
            );
        }
    }

    // Call only after an item is successfully saved with quantity zero.
    public void sendZeroStockAlert(String itemName) {
        if (!preferences.getBoolean("enabled", false) || !hasPermission()) {
            statusText.setText(
                    "Item is out of stock. SMS skipped because alerts are off."
            );
            return;
        }

        String phone = preferences.getString("phone", "");

        if (phone.isEmpty()) {
            statusText.setText("SMS skipped. Enable alerts with a phone number.");
            return;
        }

        try {
            SmsManager manager =
                    activity.getSystemService(SmsManager.class);

            if (manager == null) {
                statusText.setText("SMS is unavailable on this device.");
                return;
            }

            // Limit the name so the alert remains short.
            String shortName = itemName.length() > 20
                    ? itemName.substring(0, 20)
                    : itemName;

            String message = "Stock alert: " + shortName
                    + " has 0 left. Restock.";

            Intent sentIntent = new Intent(sentAction)
                    .setPackage(activity.getPackageName());

            PendingIntent sentPendingIntent = PendingIntent.getBroadcast(
                    activity,
                    ++requestNumber,
                    sentIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
                            | PendingIntent.FLAG_IMMUTABLE
            );

            statusText.setText("Submitting zero-stock SMS...");

            manager.sendTextMessage(
                    phone,
                    null,
                    message,
                    sentPendingIntent,
                    null
            );
        } catch (RuntimeException exception) {
            statusText.setText(
                    "Inventory saved, but SMS could not be submitted."
            );
        }
    }

    public void close() {
        activity.unregisterReceiver(sentReceiver);
    }
}