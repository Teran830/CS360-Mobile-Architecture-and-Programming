package com.example.jorgeteranmodulethree;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    // Run database and password operations away from the screen's thread.
    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> processAccount(false));
        createAccountButton.setOnClickListener(v -> processAccount(true));
    }

    private void processAccount(boolean creatingAccount) {

        String username =
                usernameEditText.getText().toString().trim();

        // Preserve the password exactly as entered.
        String password =
                passwordEditText.getText().toString();

        if (username.isEmpty()) {
            usernameEditText.setError("Enter a username.");
            usernameEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordEditText.setError("Enter a password.");
            passwordEditText.requestFocus();
            return;
        }

        setBusy(true);

        databaseExecutor.execute(() -> {
            String message;
            boolean loginSuccessful = false;
            boolean accountCreated = false;

            try {
                if (creatingAccount) {

                    if (databaseHelper.usernameExists(username)) {
                        message = "That username already exists. Choose another.";

                    } else {
                        accountCreated =
                                databaseHelper.createUser(username, password);

                        message = accountCreated
                                ? "Account created. You can now log in."
                                : "Account could not be created. Try another username.";
                    }

                } else {
                    loginSuccessful =
                            databaseHelper.checkUser(username, password);

                    message = loginSuccessful
                            ? "Login successful."
                            : "Incorrect username or password.";
                }

            } catch (RuntimeException exception) {
                Log.e("MainActivity", "Account operation failed.", exception);
                message = "Unable to access your account. Please try again.";
            }

            final String resultMessage = message;
            final boolean openInventory = loginSuccessful;
            final boolean clearPassword = accountCreated;

            runOnUiThread(() -> {

                // Do not update a screen that has already closed.
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                setBusy(false);

                Toast.makeText(
                        MainActivity.this,
                        resultMessage,
                        Toast.LENGTH_LONG
                ).show();

                if (clearPassword) {
                    passwordEditText.setText("");
                    passwordEditText.requestFocus();
                }

                if (openInventory) {
                    passwordEditText.setText("");

                    Intent intent = new Intent(
                            MainActivity.this,
                            InventoryActivity.class
                    );

                    startActivity(intent);
                }
            });
        });
    }

    private void setBusy(boolean busy) {
        loginButton.setEnabled(!busy);
        createAccountButton.setEnabled(!busy);
        usernameEditText.setEnabled(!busy);
        passwordEditText.setEnabled(!busy);

        loginButton.setText(busy ? "PLEASE WAIT..." : "LOG IN");
    }

    @Override
    protected void onDestroy() {
        // Close the database after any queued operation finishes.
        databaseExecutor.execute(() -> databaseHelper.close());
        databaseExecutor.shutdown();

        super.onDestroy();
    }
}