package com.example.jorgeteranmodulethree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String USERS_TABLE = "users";
    private static final String INVENTORY_TABLE = "inventory";

    private static final int HASH_ITERATIONS = 600000;
    private static final int HASH_LENGTH = 256;

    public DatabaseHelper(Context context) {
        super(
                context.getApplicationContext(),
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store account credentials separately from inventory.
        db.execSQL(
                "CREATE TABLE " + USERS_TABLE + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash BLOB NOT NULL, " +
                        "salt BLOB NOT NULL)"
        );

        // Inventory starts empty so users can add their own items.
        db.execSQL(
                "CREATE TABLE " + INVENTORY_TABLE + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL CHECK(quantity >= 0))"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        // Add a migration here when the database structure changes.
        // Do not delete tables because that would erase saved data.
        throw new IllegalStateException(
                "No database migration defined from " +
                        oldVersion + " to " + newVersion
        );
    }

    // Check whether a username is already registered.
    public boolean usernameExists(String username) {

        try (Cursor cursor = getReadableDatabase().query(
                USERS_TABLE,
                new String[]{"id"},
                "username = ?",
                new String[]{username.trim()},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst();
        }
    }

    // Save a new account using a salted password hash.
    public boolean createUser(String username, String password) {

        if (username == null || password == null ||
                username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", hashPassword(password, salt));
        values.put("salt", salt);

        long result = getWritableDatabase().insertWithOnConflict(
                USERS_TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );

        return result != -1;
    }

    // Return true only when the saved account matches the password.
    public boolean checkUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        try (Cursor cursor = getReadableDatabase().query(
                USERS_TABLE,
                new String[]{"password_hash", "salt"},
                "username = ?",
                new String[]{username.trim()},
                null,
                null,
                null
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] savedHash = cursor.getBlob(
                    cursor.getColumnIndexOrThrow("password_hash")
            );

            byte[] salt = cursor.getBlob(
                    cursor.getColumnIndexOrThrow("salt")
            );

            byte[] enteredHash = hashPassword(password, salt);

            return MessageDigest.isEqual(savedHash, enteredHash);
        }
    }

    private byte[] hashPassword(String password, byte[] salt) {

        PBEKeySpec specification = new PBEKeySpec(
                password.toCharArray(),
                salt,
                HASH_ITERATIONS,
                HASH_LENGTH
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            return factory.generateSecret(specification).getEncoded();

        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException(
                    "Unable to process password securely.",
                    exception
            );

        } finally {
            specification.clearPassword();
        }
    }

    // CREATE: Add an inventory record.
    public boolean addItem(String name, int quantity) {

        if (name == null || name.trim().isEmpty() || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);

        long result = getWritableDatabase().insert(
                INVENTORY_TABLE,
                null,
                values
        );

        return result != -1;
    }

    // READ: The calling activity must close the returned cursor.
    public Cursor getAllItems() {

        return getReadableDatabase().query(
                INVENTORY_TABLE,
                new String[]{"id", "name", "quantity"},
                null,
                null,
                null,
                null,
                "name COLLATE NOCASE ASC, id ASC"
        );
    }

    // UPDATE: Change the selected item's name and quantity.
    public boolean updateItem(long id, String name, int quantity) {

        if (id <= 0 || name == null ||
                name.trim().isEmpty() || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);

        int updatedRows = getWritableDatabase().update(
                INVENTORY_TABLE,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return updatedRows == 1;
    }

    // DELETE: Remove only the selected inventory record.
    public boolean deleteItem(long id) {

        int deletedRows = getWritableDatabase().delete(
                INVENTORY_TABLE,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return deletedRows == 1;
    }
}